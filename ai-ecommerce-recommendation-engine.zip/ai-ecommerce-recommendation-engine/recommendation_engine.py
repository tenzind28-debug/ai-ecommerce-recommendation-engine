
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

EVENT_WEIGHTS = {
    "view": 1,
    "wishlist": 3,
    "cart": 5,
    "purchase": 10,
}

class RecommendationEngine:
    def __init__(self, products_path="data/products.csv", interactions_path="data/interactions.csv"):
        self.products = pd.read_csv(products_path)
        self.interactions = pd.read_csv(interactions_path)

        text = (
            self.products["category"].fillna("") + " " +
            self.products["brand"].fillna("") + " " +
            self.products["colour"].fillna("") + " " +
            self.products["style"].fillna("") + " " +
            self.products["description"].fillna("")
        )

        self.vectorizer = TfidfVectorizer(stop_words="english")
        self.matrix = self.vectorizer.fit_transform(text)
        self.similarity = cosine_similarity(self.matrix)

        self.product_index = pd.Series(
            self.products.index, index=self.products["product_id"]
        ).to_dict()

        self.name_index = pd.Series(
            self.products.index, index=self.products["product_name"]
        ).to_dict()

        weighted = self.interactions.copy()
        weighted["weight"] = weighted["event"].map(EVENT_WEIGHTS).fillna(0)
        self.weighted_interactions = weighted

    def recommend_similar(self, product_id, n=5):
        if product_id not in self.product_index:
            return self.products.head(n).copy()

        idx = self.product_index[product_id]
        scores = list(enumerate(self.similarity[idx]))
        scores = sorted(scores, key=lambda x: x[1], reverse=True)

        recommendations = []
        for i, score in scores:
            pid = int(self.products.iloc[i]["product_id"])
            if pid == int(product_id):
                continue
            recommendations.append((i, score))
            if len(recommendations) >= n:
                break

        result = self.products.iloc[[x[0] for x in recommendations]].copy()
        result["similarity_score"] = [round(float(x[1]), 3) for x in recommendations]
        return result

    def recommend_for_user(self, user_id, n=5):
        user_data = self.weighted_interactions[
            self.weighted_interactions["user_id"] == user_id
        ]

        if user_data.empty:
            return self.popular_products(n)

        # Build a preference vector from products the user interacted with.
        scores = np.zeros(len(self.products))
        for _, row in user_data.iterrows():
            pid = int(row["product_id"])
            if pid in self.product_index:
                idx = self.product_index[pid]
                scores += self.similarity[idx] * float(row["weight"])

        # Remove already purchased products.
        purchased = set(
            user_data.loc[user_data["event"] == "purchase", "product_id"].astype(int)
        )

        ranked = np.argsort(scores)[::-1]
        output = []
        for idx in ranked:
            pid = int(self.products.iloc[idx]["product_id"])
            if pid in purchased:
                continue
            output.append((idx, scores[idx]))
            if len(output) >= n:
                break

        if not output:
            return self.popular_products(n)

        result = self.products.iloc[[x[0] for x in output]].copy()
        max_score = max(float(x[1]) for x in output) or 1
        result["recommendation_score"] = [
            round(float(x[1]) / max_score, 3) for x in output
        ]
        return result

    def popular_products(self, n=5):
        purchase_counts = (
            self.interactions[self.interactions["event"] == "purchase"]
            .groupby("product_id")
            .size()
            .sort_values(ascending=False)
        )
        ids = list(purchase_counts.index[:n])
        return self.products[self.products["product_id"].isin(ids)].copy()

    def recommendation_reason(self, user_id, product_id):
        user_data = self.weighted_interactions[
            self.weighted_interactions["user_id"] == user_id
        ]
        if user_data.empty:
            return "Popular among shoppers"

        target = self.products[self.products["product_id"] == product_id].iloc[0]
        categories_seen = set()
        brands_seen = set()
        for pid in user_data["product_id"]:
            p = self.products[self.products["product_id"] == int(pid)]
            if not p.empty:
                categories_seen.add(p.iloc[0]["category"])
                brands_seen.add(p.iloc[0]["brand"])

        reasons = []
        if target["category"] in categories_seen:
            reasons.append("matches a category you interacted with")
        if target["brand"] in brands_seen:
            reasons.append("matches a brand you interacted with")
        if not reasons:
            reasons.append("similar to products you interacted with")
        return " and ".join(reasons).capitalize()
