from recommendation_engine import RecommendationEngine

engine = RecommendationEngine()
sample = engine.products.iloc[0]
print("Selected product:", sample["product_name"])
print(engine.recommend_similar(int(sample["product_id"]), 5)[["product_name","similarity_score"]])

sample_user = engine.interactions["user_id"].iloc[0]
print("\nSample user:", sample_user)
print(engine.recommend_for_user(sample_user, 5)[["product_name","category"]])
