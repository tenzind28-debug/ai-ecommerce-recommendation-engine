# AI E-commerce Recommendation Engine

A beginner-friendly Product Management + Machine Learning portfolio project that recommends relevant products using product attributes and weighted customer behaviour.

## Product problem

Large e-commerce catalogues create choice overload. A recommendation module can improve product discovery, engagement and conversion by showing products relevant to a customer's interests.

## What this prototype does

1. Builds a product catalogue.
2. Converts product text and attributes into TF-IDF vectors.
3. Uses cosine similarity to identify similar products.
4. Adds weighted customer behaviour:
   - View = 1
   - Wishlist = 3
   - Add to cart = 5
   - Purchase = 10
5. Generates personalized recommendations.
6. Includes a popularity fallback for cold-start users.
7. Shows recommendation explanations.
8. Provides a Streamlit interface and PM KPI dashboard.

## Product thinking

### Primary KPI
Recommendation CTR = recommendation clicks / recommendation impressions

### Secondary KPIs
- Add-to-cart rate
- Recommendation conversion rate
- Revenue per session
- Average order value
- Repeat purchase rate

### Key product trade-offs
- Relevance vs diversity
- Personalization vs cold-start performance
- Model quality vs latency
- User preference vs business rules
- Accuracy vs inventory availability

## Architecture

```text
Customer
   |
   v
Streamlit UI
   |
   v
Recommendation Engine
   |----------------------|
   v                      v
Product similarity    User behaviour
(TF-IDF + cosine)     (weighted events)
   |----------------------|
             |
             v
        Ranking layer
             |
             v
      Top recommendations
```

## Project structure

```text
ecommerce-recommendation-engine/
├── app.py
├── recommendation_engine.py
├── requirements.txt
├── data/
│   ├── products.csv
│   └── interactions.csv
├── notebooks/
│   └── model_exploration.ipynb
└── README.md
```

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deployment

This repository is designed for Streamlit Community Cloud. Connect the GitHub repository, select `app.py` as the main file, and deploy.

## Important note

The included dataset is synthetic and created for portfolio/learning purposes. The KPI values shown by the dashboard describe the prototype dataset and should not be presented as real business impact.

## Future improvements

- Collaborative filtering
- Hybrid recommendation model
- Real-time event tracking
- Product availability filtering
- Diversity-aware ranking
- A/B testing framework
- Recommendation explanations using an LLM
- Online learning from new customer events
- Monitoring for model drift
