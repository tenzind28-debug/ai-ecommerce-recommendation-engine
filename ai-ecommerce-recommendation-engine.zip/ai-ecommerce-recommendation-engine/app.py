
import streamlit as st
import pandas as pd
from recommendation_engine import RecommendationEngine

st.set_page_config(
    page_title="AI Commerce Recommender",
    page_icon="🛍️",
    layout="wide"
)

@st.cache_resource
def load_engine():
    return RecommendationEngine()

engine = load_engine()
products = engine.products
users = sorted(engine.interactions["user_id"].unique())

st.title("🛍️ AI E-commerce Recommendation Engine")
st.caption("A beginner-friendly product + ML prototype using content similarity and weighted user behaviour.")

with st.sidebar:
    st.header("Customer")
    user_id = st.selectbox("Select customer", users)
    st.divider()
    st.header("Recommendation mode")
    mode = st.radio(
        "Choose how recommendations are generated",
        ["Personalized", "Similar Products"]
    )

    st.divider()
    st.header("Product Manager KPIs")
    total_interactions = len(engine.interactions)
    purchases = (engine.interactions["event"] == "purchase").sum()
    carts = (engine.interactions["event"] == "cart").sum()
    purchase_rate = purchases / total_interactions if total_interactions else 0

    c1, c2 = st.columns(2)
    c1.metric("Interactions", f"{total_interactions:,}")
    c2.metric("Purchase events", f"{purchases:,}")
    c3, c4 = st.columns(2)
    c3.metric("Cart events", f"{carts:,}")
    c4.metric("Purchase / interaction", f"{purchase_rate:.1%}")

st.subheader("Recommendation Experience")

if mode == "Personalized":
    recs = engine.recommend_for_user(user_id, n=6)
    st.write(f"Recommendations for **{user_id}**")
else:
    selected_name = st.selectbox("Select a product", products["product_name"].tolist())
    selected_id = int(products.loc[products["product_name"] == selected_name, "product_id"].iloc[0])
    recs = engine.recommend_similar(selected_id, n=6)
    st.write(f"Products similar to **{selected_name}**")

cols = st.columns(3)
for i, (_, row) in enumerate(recs.iterrows()):
    with cols[i % 3]:
        st.markdown(f"### {row['product_name']}")
        st.write(f"**{row['brand']} · {row['category']}**")
        st.write(f"₹{row['price']:,.0f}  ·  ⭐ {row['rating']}")
        if mode == "Personalized":
            score = row.get("recommendation_score", 0)
            st.progress(min(float(score), 1.0))
            st.caption(f"Recommendation score: {score:.2f}")
            st.caption(engine.recommendation_reason(user_id, int(row["product_id"])))
        else:
            score = row.get("similarity_score", 0)
            st.progress(min(float(score), 1.0))
            st.caption(f"Similarity: {score:.2f}")
        st.button("View product", key=f"view_{mode}_{row['product_id']}")

st.divider()
st.subheader("Why this project matters from a Product Management perspective")

pm_cols = st.columns(4)
pm_cols[0].metric("Primary KPI", "Recommendation CTR")
pm_cols[1].metric("North Star", "Revenue / Session")
pm_cols[2].metric("Key ML signal", "User intent")
pm_cols[3].metric("Fallback", "Popularity")

st.info(
    "Production considerations: cold-start users, out-of-stock products, recommendation diversity, "
    "business rules, latency, experimentation and monitoring."
)
